const Query=require('../models/query')
const nodemailer=require('nodemailer')



exports.adminqueryselection=async(req,res)=>{
    const record=await Query.find()
    //console.log(record)
    res.render('admin/query.ejs',{record})
}
exports.adminqueryreplyform=async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    const record=await Query.findById(id)
    //console.log(record)
    res.render('admin/replyform.ejs',{record})
}

exports.adminqueryreplysent=async(req,res)=>{
    //console.log(req.file)
    //console.log(req.params.id)
    //console.log(req.body)
    
    const id=req.params.id
    const{emailto,emailfrom,subject,body}=req.body
    //nodemailer
    let testAccount = await nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'deepdd4148@gmail.com', // generated ethereal user
      pass: 'fezkbfuxsokragfv', // generated ethereal password
    },
  });
  console.log('Connected To Gmail SMTP Server')
  if(req.file){
    const path=req.file.path
    let info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<b>Hello world?</b>", // html body
        attachments:[{
            path:path
        }]
      });
  }else{
    let info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<b>Hello world?</b>", // html body
    })
  }
  
  console.log('Email Sent')
  await Query.findByIdAndUpdate(id,{status:'Replied'})
  res.redirect('/admin/query')
}

exports.adminquerydelete=async(req,res)=>{
    //console.log(req.params.id)
    const id=req.params.id
    await Query.findByIdAndDelete(id)
    res.redirect('/admin/query')
}