const Service=require('../models/service')


exports.adminserviceselection=async(req,res)=>{
    const record= await Service.find().sort({postedDate:-1})//sorting assending(+1) and disassending(-1)
    //console.log(record)
    const totalService=await Service.count()
    //console.log(totalService)
    const publishcount=await Service.count({status:'publish'})
    //console.log(publishcount);
    const unpublishcount=await Service.count({status:'unpublish'})
    //console.log(unpublishcount);
    res.render('admin/service.ejs',{record,totalService,publishcount,unpublishcount})
}

exports.adminserviceaddform=(req,res)=>{
    res.render('admin/serviceform.ejs')
}
exports.adminserviceadd=(req,res)=>{
    //console.log(req.file)
    const filename=req.file.filename
    //console.log(req.body)
    const {sname,sdesc,sldesc}=req.body
    let currentDateTime= new Date()
    const record=new Service({name:sname,desc:sdesc,ldesc:sldesc,postedDate:currentDateTime,img:filename})
    //console.log(record);
    record.save()
    res.redirect('/admin/service')
}

exports.adminservicedelete=async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    await Service.findByIdAndDelete(id)
    res.redirect('/admin/service')
}

exports.adminservicestatusupdate=async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    const record=await Service.findById(id)
    //console.log(record)
    let currentstatus=null
    if(record.status=='unpublish'){
        currentstatus='publish'
    }else{
        currentstatus='unpublish'
    }
    const current=await Service.findByIdAndUpdate(id,{status:currentstatus})
    //console.log(current)
    res.redirect('/admin/service')
}