const Testi=require('../models/testi')



exports.admintestiselectionpage=async(req,res)=>{
    const record=await Testi.find().sort({postedDate:-1})
    //console.log(record)
    const totaltesti=await Testi.count()
    //console.log(totaltesti)
    const publishtesti=await Testi.count({status:'publish'})
    //console.log(publishtesti)
    const unpublishtesti=await Testi.count({status:'unpublish'})
    //console.log(unpublishtesti)
    res.render('admin/testi.ejs',{record,totaltesti,publishtesti,unpublishtesti})
}

exports.admintestistatusupdate=async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    const record=await Testi.findById(id)
    //console.log(record)
    let newstatus=null
    if(record.status=='unpublish'){
        newstatus='publish'
    }else{
        newstatus='unpublish'
    }
    await Testi.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/testi')
}

exports.admintestidelete=async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}