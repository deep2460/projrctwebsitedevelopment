const Banner=require('../models/banner')

exports.adminbannerpage=async(req,res)=>{
    const record=await Banner.findOne()
    //console.log(record)
    res.render('admin/banner.ejs',{record})
}

exports.adminbannerupdateform=async(req,res)=>{
    const id=req.params.id
    //console.log(id);
    const record=await Banner.findById(id)
    //console.log(record)
    res.render('admin/bannerform.ejs',{record})
}

exports.adminbannerupdate=async(req,res)=>{
    //console.log(req.file)
    //console.log(req.body)
    //console.log(req.params.id)
    const{title,desc,ldesc,img}=req.body
    const id=req.params.id
    if(req.file){
        const filename=req.file.filename
        await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc,img:filename})
    }else{
        await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc})
    }
    res.redirect('/admin/banner')
}