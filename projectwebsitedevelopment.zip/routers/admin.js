const router=require('express').Router()//module
const Reg=require('../models/reg')
const Banner=require('../models/banner')
const Service=require('../models/service')
const Testi=require('../models/testi')
const multer=require('multer')
const Query=require('../models/query')
const nodemailer=require('nodemailer')
const { attachment } = require('express/lib/response')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const regc=require('../controllers/regcontroller')
const queryc=require('../controllers/querycontroller')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:4*1024*1024}
})


router.get('/',regc.adminloginhomepage)
router.post('/',regc.adminlogincheck)
router.get('/dashboard',regc.admindashboard)

router.get('/banner',bannerc.adminbannerpage)
router.get('/bannerupdate/:id',bannerc.adminbannerupdateform)
router.post('/bannerupdate/:id',upload.single('img'),bannerc.adminbannerupdate)

router.get('/service',servicec.adminserviceselection)
router.get('/serviceadd',servicec.adminserviceaddform)
router.post('/serviceadd',upload.single('img'),servicec.adminserviceadd)
router.get('/servicedelete/:id',servicec.adminservicedelete)
router.get('/servicestatusupdate/:id',servicec.adminservicestatusupdate)


router.get('/testi',testic.admintestiselectionpage)
router.get('/testistatusupdate/:id',testic.admintestistatusupdate)
router.get('/testidelete/:id',testic.admintestidelete)


router.get('/query',queryc.adminqueryselection)
router.get('/reply/:id',queryc.adminqueryreplyform)
router.post('/reply/:id',upload.single('attachment'),queryc.adminqueryreplysent)
router.get('/querydelete/:id',queryc.adminquerydelete)







module.exports=router