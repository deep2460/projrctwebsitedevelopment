const router=require('express').Router()//module
const Banner=require('../models/banner')
const Service=require('../models/service')
const Testi=require('../models/testi')
const multer=require('multer')
const Query=require('../models/query')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const regc=require('../controllers/regcontroller')
const queryc=require('../controllers/querycontroller')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:4*1024*1024}
})


router.get('/',async(req,res)=>{
    const bannerRecord=await Banner.findOne()
    //console.log(bannerRecord)
    const serviceRecord=await Service.find({status:'publish'})
    //console.log(serviceRecord)
    const testiRecord=await Testi.find({status:'publish'})
    //console.log(testiRecord)
    res.render('index.ejs',{bannerRecord,serviceRecord,testiRecord})
})

router.get('/banner',async(req,res)=>{
    const record=await Banner.findOne()
    //console.log(record)
    res.render('banner.ejs',{record})
})

router.get('/servicedetail/:id',async(req,res)=>{
    const id=req.params.id
    //console.log(id)
    const record=await Service.findById(id)
    //console.log(record)
    res.render('servicedetail.ejs',{record})
})

router.get('/testi',(req,res)=>{
    res.render('testiform.ejs')
})
router.post('/testi',upload.single('img'),(req,res)=>{
    //console.log(req.file)
    //console.log(req.body)
    const {quotes,name}=req.body
    let currentDateTime= new Date()
    if(req.file){
        const filename=req.file.filename
        const record=new Testi({quotes:quotes,name:name,postedDate:currentDateTime,img:filename})
        record.save()
    }else{
        const record=new Testi({quotes:quotes,name:name,postedDate:currentDateTime,img:'avatar.png'})
        record.save()
    }
    //console.log(record)
    res.redirect('/testi')
})

router.post('/',(req,res)=>{
    //console.log(req.body)
    const {email,query}=req.body
    const record=new Query({email:email,query:query})
    record.save()
    //console.log(record)
    res.redirect('/')
})








module.exports=router